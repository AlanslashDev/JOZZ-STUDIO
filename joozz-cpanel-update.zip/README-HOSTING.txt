JOOZZ STUDIO — SAFE CPANEL UPDATE

This package updates the running site. It does not replace your database or
change your existing admin accounts.

BEFORE UPLOADING
1. In cPanel File Manager, make a backup copy of the current site files.
2. Do not delete or replace your existing .env file, database, or storage/uploads folder.
3. Confirm the domain document root is the folder containing index.php and index.html.

UPLOAD
1. Extract this ZIP on your computer.
2. Upload the files and folders inside the extracted package to the existing
   domain document root, allowing new application files to replace old ones.
3. Preserve the current .env and storage/uploads files when prompted.
4. In phpMyAdmin, select the same database currently used by the site and
   import database/migrations/005_admin_activity_log.sql only if the admin
   activity_log table does not already exist. Do not import complete_setup.sql
   or the initial seed files over the live database.
5. Ensure storage/cache and storage/sessions are writable by PHP (usually 775).

CHECK
Visit the homepage, then /admin, sign in with your existing account, and check
that the Media Library loads. The site and API use the same domain.

If the database already has activity_log, skip migration 005. This update does
not migrate or erase existing content, enquiries, admins, or uploaded media.
